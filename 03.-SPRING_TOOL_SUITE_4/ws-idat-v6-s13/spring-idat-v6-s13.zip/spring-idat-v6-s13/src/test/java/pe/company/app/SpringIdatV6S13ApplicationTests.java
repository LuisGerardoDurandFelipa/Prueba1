package pe.company.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIdatV6S13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
